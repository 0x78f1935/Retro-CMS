export interface IAssetDimension
{
    x: number;
    y: number;
    z?: number;
}