﻿export class GeometryType
{
    public static VERTICAL: string = 'vertical';
    public static SITTING: string = 'sitting';
    public static HORIZONTAL: string = 'horizontal';
    public static SWIM: string = 'swim';
    public static SNOWWARS_HORIZONTAL: string = 'swhorizontal';
}
