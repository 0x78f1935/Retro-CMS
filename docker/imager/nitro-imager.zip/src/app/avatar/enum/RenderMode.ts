﻿export class RenderMode
{
    public static TOOL: string = 'tool';
    public static COMPONENT: string = 'component';
    public static ONLINE_TOOL: string = 'online_tool';
    public static LOCAL_ONLY: string = 'local_only';
}
