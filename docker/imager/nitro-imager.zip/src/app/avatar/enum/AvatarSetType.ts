﻿export class AvatarSetType
{
    public static FULL: string = 'full';
    public static HEAD: string = 'head';
    public static BODY: string = 'body';
}