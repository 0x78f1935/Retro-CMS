﻿export class AvatarScaleType
{
    public static LARGE: string = 'h';
    public static SMALL: string = 'sh';
}