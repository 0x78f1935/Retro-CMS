export interface IPartColor
{
    id: number;
    index: number;
    clubLevel: number;
    isSelectable: boolean;
    rgb: number;
}
