﻿export interface IAvatarDataContainer
{
    ink: number;
    paletteIsGrayscale: boolean;
    reds: number[];
    greens: number[];
    blues: number[];
    alphas: number[];
}
