require('./src/main');
