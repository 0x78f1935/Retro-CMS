export interface IConverter
{
    convertAsync(): Promise<void>;
}
