export class ConverterResult
{
    public static OK: number = 1;
    public static BAD_ARGS: number = 2;
    public static FILE_EXISTS: number = 3;
    public static INVALID_SWF: number = 4;
}
