export interface IAssetPlaneVisualizationAnimatedLayerItem
{
    id?: number;
    assetId?: string;
    x?: string;
    y?: string;
    randomX?: string;
    randomY?: string;
    speedX?: number;
    speedY?: number;
}
