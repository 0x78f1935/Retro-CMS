export interface IAssetAnimationSpriteDirection
{
    id?: number;
    dx?: number;
    dy?: number;
    dz?: number;
}
