export * from './IFigureMap';
export * from './IFigureMapLibrary';
export * from './IFigureMapLibraryPart';
