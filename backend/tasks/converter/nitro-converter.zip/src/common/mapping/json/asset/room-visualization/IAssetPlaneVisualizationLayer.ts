export interface IAssetPlaneVisualizationLayer
{
    materialId?: string;
    color?: number;
    offset?: number;
    align?: string;
}
