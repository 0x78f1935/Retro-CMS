import { IAssetPlaneMaterialCellExtraItemData } from './IAssetPlaneMaterialCellExtraItemData';

export interface IAssetPlaneMaterialCell
{
    textureId?: string;
    extraData?: IAssetPlaneMaterialCellExtraItemData;
}
