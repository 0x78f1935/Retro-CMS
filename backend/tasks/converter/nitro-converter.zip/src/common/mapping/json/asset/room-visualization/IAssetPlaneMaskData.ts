import { IAssetPlaneMask } from './IAssetPlaneMask';

export interface IAssetPlaneMaskData
{
    masks?: IAssetPlaneMask[];
}
