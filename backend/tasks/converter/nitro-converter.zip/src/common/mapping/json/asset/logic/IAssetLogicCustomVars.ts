export interface ICustomVars
{
    variables?: string[];
}
