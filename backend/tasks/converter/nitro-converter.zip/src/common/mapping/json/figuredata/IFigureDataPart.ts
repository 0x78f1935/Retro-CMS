export interface IFigureDataPart
{
    id?: number;
    type?: string;
    colorable?: boolean;
    index?: number;
    colorindex?: number;
}
