export * from './IFurnitureData';
export * from './IFurnitureType';
