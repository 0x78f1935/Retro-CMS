export interface IExternalTexts
{
    [index: string]: string
}
