export * from './IExternalTexts';
