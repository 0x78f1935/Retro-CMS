import { IAssetPlaneTextureBitmap } from './IAssetPlaneTextureBitmap';

export interface IAssetPlaneMaskVisualization
{
    size?: number;
    bitmaps?: IAssetPlaneTextureBitmap[];
}
