export interface IAssetAnimationFramePartItem
{
    id?: string;
    base?: string;
}
