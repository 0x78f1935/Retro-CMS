import { IAssetPlaneTextureBitmap } from './IAssetPlaneTextureBitmap';

export interface IAssetPlaneTexture
{
    id?: string;
    bitmaps?: IAssetPlaneTextureBitmap[];
}
