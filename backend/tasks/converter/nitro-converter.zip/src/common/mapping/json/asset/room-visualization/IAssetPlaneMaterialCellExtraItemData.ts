export interface IAssetPlaneMaterialCellExtraItemData
{
    limitMax?: number;
    extraItemTypes?: string[];
    offsets?: [number, number][];
}
