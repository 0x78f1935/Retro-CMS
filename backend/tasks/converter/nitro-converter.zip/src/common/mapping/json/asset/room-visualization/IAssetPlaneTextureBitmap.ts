export interface IAssetPlaneTextureBitmap
{
    assetName?: string;
    normalMinX?: number;
    normalMaxX?: number;
    normalMinY?: number;
    normalMaxY?: number;
}
