export interface IAssetAnimationAdd
{
    id?: string;
    align?: string;
    blend?: string;
    ink?: number;
    base?: string;
}
