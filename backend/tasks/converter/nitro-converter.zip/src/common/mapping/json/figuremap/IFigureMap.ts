import { IFigureMapLibrary } from './IFigureMapLibrary';

export interface IFigureMap
{
    libraries?: IFigureMapLibrary[];
}
