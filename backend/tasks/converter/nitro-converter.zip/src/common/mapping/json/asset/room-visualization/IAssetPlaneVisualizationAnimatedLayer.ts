import { IAssetPlaneVisualizationAnimatedLayerItem } from './IAssetPlaneVisualizationAnimatedLayerItem';

export interface IAssetPlaneVisualizationAnimatedLayer
{
    items?: IAssetPlaneVisualizationAnimatedLayerItem[];
}
