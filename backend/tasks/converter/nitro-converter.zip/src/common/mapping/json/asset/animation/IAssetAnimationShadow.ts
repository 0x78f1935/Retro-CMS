export interface IAssetAnimationShadow
{
    id?: string;
}
