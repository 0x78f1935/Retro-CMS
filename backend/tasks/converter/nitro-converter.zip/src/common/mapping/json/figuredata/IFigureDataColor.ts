export interface IFigureDataColor
{
    id?: number;
    index?: number;
    club?: number;
    selectable?: boolean;
    hexCode?: string;
}
