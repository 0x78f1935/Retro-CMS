export interface IAssetGesture
{
    id?: string;
    animationId?: number;
}
