export * from './IFigureData';
export * from './IFigureDataColor';
export * from './IFigureDataHiddenLayer';
export * from './IFigureDataPalette';
export * from './IFigureDataPart';
export * from './IFigureDataSet';
export * from './IFigureDataSetType';
