import { IEffectMapLibrary } from './IEffectMapLibrary';

export interface IEffectMap
{
    effects?: IEffectMapLibrary[];
}
