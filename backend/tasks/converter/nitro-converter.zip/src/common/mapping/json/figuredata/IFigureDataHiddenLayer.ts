export interface IFigureDataHiddenLayer
{
    partType?: string;
}
