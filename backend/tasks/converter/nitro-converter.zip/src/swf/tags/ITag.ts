export interface ITag
{
    code: number;
}
