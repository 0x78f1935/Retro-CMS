export interface ISWFFrameSize
{
    x: number;
    y: number;
    width: number;
    height: number;
}
