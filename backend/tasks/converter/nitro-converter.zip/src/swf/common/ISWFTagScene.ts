export interface ISWFTagScene
{
    offset: number;
    name: string;
}
