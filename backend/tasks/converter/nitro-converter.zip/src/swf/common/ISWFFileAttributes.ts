export interface ISWFFileAttributes
{
    useNetwork: boolean,
    as3: boolean,
    hasMetaData: boolean,
    useGPU: boolean,
    useDirectBit: boolean
}
