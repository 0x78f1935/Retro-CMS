export interface ISWFFileLength
{
    compressed: number;
    uncompressed: number;
}
