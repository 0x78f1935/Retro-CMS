export interface ISWFTagSymbol
{
    id: number;
    name: string;
}
